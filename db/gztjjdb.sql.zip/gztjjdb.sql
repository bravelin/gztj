-- phpMyAdmin SQL Dump
-- version 2.7.0-pl1
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2017 年 05 月 17 日 00:42
-- 服务器版本: 5.1.63
-- PHP 版本: 5.2.17
-- 
-- 数据库: `gztjjdb`
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `t_article`
-- 

CREATE TABLE IF NOT EXISTS `t_article` (
  `id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `content` mediumtext,
  `browse_count` int(11) DEFAULT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `add_user` varchar(30) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  `publish_time` datetime DEFAULT NULL,
  `key_words` varchar(50) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `is_published` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_demeanour_images`
-- 

CREATE TABLE IF NOT EXISTS `t_demeanour_images` (
  `id` int(11) NOT NULL DEFAULT '0',
  `image_describe` varchar(80) DEFAULT NULL,
  `image_path` varchar(200) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_dishonesty_notice`
-- 

CREATE TABLE IF NOT EXISTS `t_dishonesty_notice` (
  `id` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `place_name` varchar(50) DEFAULT NULL,
  `link` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_each_economic_indicator`
-- 

CREATE TABLE IF NOT EXISTS `t_each_economic_indicator` (
  `id` int(11) NOT NULL DEFAULT '0',
  `place` varchar(40) DEFAULT NULL,
  `yearmonth` char(6) DEFAULT NULL,
  `sc_v` float DEFAULT NULL,
  `sc_p` float DEFAULT NULL,
  `cz_v` float DEFAULT NULL,
  `cz_p` float DEFAULT NULL,
  `gg_v` float DEFAULT NULL,
  `gg_p` float DEFAULT NULL,
  `gm_v` float DEFAULT NULL,
  `gm_p` float DEFAULT NULL,
  `gd_v` float DEFAULT NULL,
  `gd_p` float DEFAULT NULL,
  `xe_v` float DEFAULT NULL,
  `xe_p` float DEFAULT NULL,
  `sj_v` float DEFAULT NULL,
  `sj_p` float DEFAULT NULL,
  `ck_v` float DEFAULT NULL,
  `ck_p` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_economic_indicator`
-- 

CREATE TABLE IF NOT EXISTS `t_economic_indicator` (
  `id` int(11) NOT NULL DEFAULT '0',
  `place` varchar(40) DEFAULT NULL,
  `yearmonth` char(6) DEFAULT NULL,
  `indicator` varchar(80) DEFAULT NULL,
  `unit` varchar(15) DEFAULT NULL,
  `indicator_value` varchar(20) DEFAULT NULL,
  `indicator_growth` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_exam_score`
-- 

CREATE TABLE IF NOT EXISTS `t_exam_score` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(30) DEFAULT NULL,
  `exam_year_month` char(6) DEFAULT NULL,
  `id_card_number` char(18) DEFAULT NULL,
  `exam_card_number` varchar(50) DEFAULT NULL,
  `am_score` varchar(10) DEFAULT NULL,
  `pm_score` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_ganzhou_info`
-- 

CREATE TABLE IF NOT EXISTS `t_ganzhou_info` (
  `place` varchar(30) NOT NULL DEFAULT '',
  `place_py` varchar(50) DEFAULT NULL,
  `place_link` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`place`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_notebook`
-- 

CREATE TABLE IF NOT EXISTS `t_notebook` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `note_type` varchar(20) DEFAULT NULL,
  `note_title` varchar(100) DEFAULT NULL,
  `note_content` varchar(5000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `note_secret` tinyint(1) DEFAULT NULL,
  `note_replay_user` varchar(30) DEFAULT NULL,
  `note_replay` varchar(5000) DEFAULT NULL,
  `replay_time` datetime DEFAULT NULL,
  `isPublish` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_opinions`
-- 

CREATE TABLE IF NOT EXISTS `t_opinions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `article_id` int(11) DEFAULT NULL,
  `nick_name` varchar(50) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `tel` char(11) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `is_published` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_role`
-- 

CREATE TABLE IF NOT EXISTS `t_role` (
  `role_name` varchar(30) NOT NULL DEFAULT '',
  `role_function` varchar(500) DEFAULT NULL,
  `create_user` varchar(30) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_subject`
-- 

CREATE TABLE IF NOT EXISTS `t_subject` (
  `id` int(11) NOT NULL DEFAULT '0',
  `subject_name` varchar(80) DEFAULT NULL,
  `image_path` varchar(200) DEFAULT NULL,
  `is_main` char(1) DEFAULT NULL,
  `is_out_link` char(1) DEFAULT NULL,
  `out_link` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- 表的结构 `t_user`
-- 

CREATE TABLE IF NOT EXISTS `t_user` (
  `user_name` varchar(30) NOT NULL,
  `pass_word` varchar(32) NOT NULL,
  `real_name` varchar(30) NOT NULL,
  `role_name` varchar(30) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `remark` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
